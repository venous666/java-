package gaycombolsonaro;

public class Main {


		public static void main(String[] args){
           
			Animal Bill = new Animal("Bill Souza", 2.5);
			Bill.SetNome("Bill cruz");
			Bill.SetPeso(2.5);
			Bill.imprimir();
			System.out.println(Bill.getNome());
		
	}
}


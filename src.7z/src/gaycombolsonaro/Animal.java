package gaycombolsonaro;

public class Animal {
	
	private String nome;
	private double peso;
	
	public Animal() {}
	public Animal(String nome, double peso) {
		this.nome = nome;
		this.peso = peso;
	}
	public Animal(String nome) {
		this.nome = nome;
		
	}
	
	public void imprimir() { 
	System.out.println("Nome: "+ this.nome + "\nPeso: " + this.peso);
	}
	
	public void SetNome(String nome) {
		this.nome = nome;
	}
	public void SetPeso(double peso) {
		this.peso = peso;
	}
	public String getNome() {
		return nome;
	}
	
}
